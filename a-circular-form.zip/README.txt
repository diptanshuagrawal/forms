A Pen created at CodePen.io. You can find this one at http://codepen.io/kindofone/pen/slnGx.

 This interface experiments with user input by implementing a circular form, that rotates as the user advances through it's path.