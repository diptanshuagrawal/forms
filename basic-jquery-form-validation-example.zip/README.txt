A Pen created at CodePen.io. You can find this one at http://codepen.io/SitePoint/pen/akPoad.

 A pen that demonstrates how to validate a user registration form with jQuery. Uses the jQuery plugin "jquery.validate".

This example is part of the article Basic jQuery Form Validation Example on SitePoint by Julian Motz: https://www.sitepoint.com/basic-jquery-form-validation-tutorial/