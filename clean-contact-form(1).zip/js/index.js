$('document').ready(function() {
  var msg = $('#message');
  msg.autosize();
});