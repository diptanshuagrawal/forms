A Pen created at CodePen.io. You can find this one at http://codepen.io/nickhaskell/pen/HoGsm.

 Clean, responsive contact form design.